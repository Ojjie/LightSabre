import React, { Component } from 'react';
import logo from '../logo.png';
// import Web3 from 'web3';
import './App.css';
import addLuggage2 from '../abis/addLuggage2.json'
const Web3 = require('web3');

class App extends Component {

  async componentWillMount() {
    await this.loadWeb3()
    console.log(window.web3.version);
    await this.loadBlockchainData()
  }

  async loadWeb3() {
    window.addEventListener('load', async () => {
      // Modern dapp browsers...
      if (window.ethereum) {
          window.web3 = new Web3(window.ethereum)
          await window.ethereum.enable()
      }
      // Legacy dapp browsers...
      else if (window.web3) {
          window.web3 = new Web3(window.web3.currentProvider)
      }
      // Non-dapp browsers...
      else {
          console.log('Non-Ethereum browser detected. You should consider trying MetaMask!')
      }
    })
  }

  async loadBlockchainData() {
    const web3 = window.web3
    web3.eth.getAccounts( (error, _accounts) => {this.setState({ account: _accounts }) } )
    const networkID = await web3.eth.net.getID()
    const abi = addLuggage2.abi
    const address = addLuggage2.networks[networkID].address
    const luggageTracker = web3.eth.contract(abi, address)
    console.log(luggageTracker)
  }

  constructor(props) {
    super(props)
    this.state = {
      account: ""
    }
  }

  render() {
    return (
      <div>
        {/* <script type="text/javascript" src="https://cdn.jsdelivr.net/gh/ethereum/web3.js@1.0.0-beta.55/dist/web3.min.js"></script> */}
        <nav className="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
          <a
            className="navbar-brand col-sm-3 col-md-2 mr-0"
            href="http://www.dappuniversity.com/bootcamp"
            target="_blank"
            rel="noopener noreferrer"
          >
            Luggage Tracker
          </a>
          <p>{this.state.account}</p>
        </nav>
        <div className="container-fluid mt-5">
          <div className="row">
            <main role="main" className="col-lg-12 d-flex text-center">
              <div className="content mr-auto ml-auto">
                <a
                  href="http://www.dappuniversity.com/bootcamp"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <img src={logo} className="App-logo" alt="logo" />
                </a>
                <h1>Dapp University Starter Kit</h1>
                <p>
                  Edit <code>src/components/App.js</code> and save to reload.
                </p>
                <a
                  className="App-link"
                  href="http://www.dappuniversity.com/bootcamp"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  LEARN BLOCKCHAIN <u><b>NOW! </b></u>
                </a>
              </div>
            </main>
          </div>
        </div>
      </div>
    );
  }
}

export default App;
