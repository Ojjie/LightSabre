import React, { Component } from 'react';


class Main extends Component {

  uuidv4() {
    return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
      (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
    );
  }


  addUUIDtoDB(uuid) {
    // create a new XMLHttpRequest
    var xhr = new XMLHttpRequest()

    // get a callback when the server responds
    xhr.addEventListener('load', () => {
      // update the state of the component with the result here
      console.log(xhr.responseText)
    })
    // open the request with the verb and the url
    xhr.open('GET', 'http://localhost:5000/addUUID/' + uuid)
    // send the request
    xhr.send()
  }

  render() {
    return (
      <div id="content">
        <h1>Add Luggage</h1>
        <form onSubmit={(event) => {
            const weight = this.luggageWeight.value
            const airport_initial = this.luggageAirport.value
            const uuid = this.uuidv4()
            this.addUUIDtoDB(uuid)
            this.props.addLuggage(uuid, weight, airport_initial)
        }}>
          <div className="form-group mr-sm-2">
            <input
              id="luggageWeight"
              type="text"
              ref={(input) => { this.luggageWeight = input }}
              className="form-control"
              placeholder="Luggage Weight"
              required />
          </div>
          <div className="form-group mr-sm-2">
            <input
              id="luggageAirport"
              type="text"
              ref={(input) => { this.luggageAirport = input }}
              className="form-control"
              placeholder="Luggage initial airport"
              required />
          </div>
          <button type="submit" className="btn btn-primary">Add Luggage</button>
        </form>

        <br />
        <h1>Send Luggage</h1>
        <form>
          <div className="form-group mr-sm-2">
            <input
              id="luggageUUID_send"
              type="text"
              ref={(input) => { this.luggageUUID_send = input }}
              className="form-control"
              placeholder="Luggage UUID"
              required />
          </div>
          <div className="form-group mr-sm-2">
            <input
              id="luggageAirportFrom_send"
              type="text"
              ref={(input) => { this.luggageAirportFrom_send = input }}
              className="form-control"
              placeholder="Luggage Source Airport"
              required />
          </div>
          <div className="form-group mr-sm-2">
            <input
              id="luggageAirportTo_send"
              type="text"
              ref={(input) => { this.luggageAirportTo_send = input }}
              className="form-control"
              placeholder="Luggage Destination Airport"
              required />
          </div>
          <button type="button" className="btn btn-primary" onClick={(event) => {
            const uuid = this.luggageUUID_send.value
            const airport_from = this.luggageAirportFrom_send.value
            const airport_to = this.luggageAirportTo_send.value
            console.log(uuid)
            // console.log("UUID exist: ", this.doesUUIDexist(uuid))
            // if(this.doesUUIDexist(uuid)) {
            //     this.props.sendLuggage(airport_from, airport_to, uuid)
            // }
            fetch('http://localhost:5000/getUUID/' + uuid)
            .then((response) => { return response.text() }) // change to return response.text()
            .then((text) => {
                console.log(text, text == "true\n")
                if (text == "true\n") {
                    this.props.sendLuggage(airport_from, airport_to, uuid)
                }
            })
        }}>Send Luggage</button>
        </form>

        <br />
        <h1>Receive Luggage</h1>
        <form>
          <div className="form-group mr-sm-2">
            <input
              id="luggageUUID_receive"
              type="text"
              ref={(input) => { this.luggageUUID_receive = input }}
              className="form-control"
              placeholder="Luggage UUID"
              required />
          </div>
          <div className="form-group mr-sm-2">
            <input
              id="luggageAirportFrom_receive"
              type="text"
              ref={(input) => { this.luggageAirportFrom_receive = input }}
              className="form-control"
              placeholder="Luggage Source Airport"
              required />
          </div>
          <div className="form-group mr-sm-2">
            <input
              id="luggageAirportTo_receive"
              type="text"
              ref={(input) => { this.luggageAirportTo_receive = input }}
              className="form-control"
              placeholder="Luggage Destination Airport"
              required />
          </div>
          <button type="button" className="btn btn-primary" onClick={(event) => {
            const uuid = this.luggageUUID_receive.value
            const airport_from = this.luggageAirportFrom_receive.value
            const airport_to = this.luggageAirportTo_receive.value
            console.log(uuid)
            // console.log("UUID exist: ", this.doesUUIDexist(uuid))
            // if(this.doesUUIDexist(uuid)) {
            //     this.props.sendLuggage(airport_from, airport_to, uuid)
            // }
            fetch('http://localhost:5000/getUUID/' + uuid)
            .then((response) => { return response.text() }) // change to return response.text()
            .then((text) => {
                console.log(text, text == "true\n")
                if (text == "true\n") {
                    this.props.receiveLuggage(airport_from, airport_to, uuid)
                }
            })
        }}>Receive Luggage</button>
        </form>

        <p> </p>
        <h2>Buy Product</h2>
        <table className="table">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Price</th>
              <th scope="col">Owner</th>
              <th scope="col"></th>
            </tr>
          </thead>
          <tbody id="productList">
            <tr>
              <th scope="row">1</th>
              <td>iPhone x</td>
              <td>1 Eth</td>
              <td>0x39C7BC5496f4eaaa1fF75d88E079C22f0519E7b9</td>
              <td><button className="buyButton">Buy</button></td>
            </tr>
            <tr>
              <th scope="row">2</th>
              <td>Macbook Pro</td>
              <td>3 eth</td>
              <td>0x39C7BC5496f4eaaa1fF75d88E079C22f0519E7b9</td>
              <td><button className="buyButton">Buy</button></td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>Airpods</td>
              <td>0.5 eth</td>
              <td>0x39C7BC5496f4eaaa1fF75d88E079C22f0519E7b9</td>
              <td><button className="buyButton">Buy</button></td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
}

export default Main;